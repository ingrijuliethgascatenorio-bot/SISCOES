import { Controller, Post, Body, UnauthorizedException } from '@nestjs/common';
import { AuthService } from '../aplicacion/auth.service';

@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('login')
  async login(@Body() body: any) {
    const user = await this.authService.validarUsuario(body.username, body.password);
    if (!user) {
      throw new UnauthorizedException('Credenciales inválidas');
    }
    return this.authService.login(user);
  }
}
