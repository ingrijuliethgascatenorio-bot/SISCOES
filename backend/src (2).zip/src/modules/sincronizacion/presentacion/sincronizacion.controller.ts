import { Controller, Post, Body, UseGuards, Request } from '@nestjs/common';
import type { Request as ExpressRequest } from 'express';
import { JwtAuthGuard } from '../../autenticacion/infraestructura/guards/jwt-auth.guard';
import { SincronizacionService } from '../aplicacion/sincronizacion.service';
import type { SyncRequestDto, SyncResponseDto } from '../dominio/dto/sync.dto';

@UseGuards(JwtAuthGuard)
@Controller('sincronizacion')
export class SincronizacionController {
  constructor(private readonly syncService: SincronizacionService) {}

  @Post()
  async sincronizar(
    @Body() dto: SyncRequestDto,
    @Request() req: any,
  ): Promise<SyncResponseDto> {
    const usuarioId: number = req.user?.userId ?? 0;
    return this.syncService.sincronizar(dto, usuarioId);
  }
}
