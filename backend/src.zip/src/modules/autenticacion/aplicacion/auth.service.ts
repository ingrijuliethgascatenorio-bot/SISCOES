import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
  constructor(private readonly jwtService: JwtService) {}

  async validarUsuario(username: string, pass: string): Promise<any> {
    // Stub de usuario para permitir compilación y pruebas básicas
    const passwordHash = await bcrypt.hash('admin123', 10);
    const user = { id: 1, username: 'admin', passwordHash };
    
    if (username === user.username && await bcrypt.compare(pass, user.passwordHash)) {
      const { passwordHash: _, ...result } = user;
      return result;
    }
    return null;
  }

  async login(user: any) {
    const payload = { username: user.username, sub: user.id };
    return {
      access_token: this.jwtService.sign(payload),
      expires_in: 28800,
    };
  }
}
