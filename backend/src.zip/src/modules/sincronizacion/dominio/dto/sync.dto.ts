export interface PersonaSyncDto {
  numero_documento: string;
  id_tipo_documento?: number;
  nombres: string;
  apellidos: string;
  fecha_nacimiento?: string;
  genero?: string;
  id_eps?: number;
  direccion?: string;
  barrio?: string;
  estrato?: string;
  correo?: string;
  estado_civil?: string;
  telefono1?: string;
  telefono2?: string;
  telefono3?: string;
  estado?: string;
  estado_sincronizacion?: string;
  fecha_actualizacion?: string;
}

export interface SyncRequestDto {
  registros: PersonaSyncDto[];
}

export interface SyncResultadoItem {
  numero_documento: string;
  accion: 'INSERT' | 'UPDATE' | 'ERROR' | 'SIN_CAMBIOS';
  campos_modificados?: string[];
  error?: string;
}

export interface SyncResponseDto {
  total_procesados: number;
  nuevos: number;
  actualizados: number;
  sin_cambios: number;
  errores: number;
  tiempo_ms: number;
  detalles: SyncResultadoItem[];
}
